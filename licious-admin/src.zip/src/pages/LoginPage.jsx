import { useState } from 'react'
import meatHero from '../assets/meat_hero.png'

// Licious Logo — drop your logo.png into the public/ folder
function LiciousLogo({ className = '', invert = false, heightClass = 'h-10' }) {
  return (
    <div className={`flex items-center ${className}`}>
      <img
        src="/logo.png"
        alt="Licious"
        className={`${heightClass} w-auto object-contain ${invert ? 'brightness-0 invert' : ''}`}
      />
    </div>
  )
}

// Shield Icon
function ShieldIcon() {
  return (
    <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z" />
    </svg>
  )
}

// Snowflake Icon
function SnowflakeIcon() {
  return (
    <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v18M3 12h18M5.636 5.636l12.728 12.728M18.364 5.636 5.636 18.364" />
    </svg>
  )
}

// Heart Icon
function HeartIcon() {
  return (
    <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12Z" />
    </svg>
  )
}

// Email Icon
function EmailIcon() {
  return (
    <svg className="w-5 h-5 text-gray-400 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <rect x="2" y="4" width="20" height="16" rx="2" />
      <path d="m2 7 8.586 5.414a2 2 0 0 0 2.828 0L22 7" />
    </svg>
  )
}

// Lock Icon
// Lock Icon
function LockIcon() {
  return (
    <svg className="w-5 h-5 text-gray-400 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <rect x="3" y="11" width="18" height="11" rx="2" />
      <path d="M7 11V7a5 5 0 0 1 10 0v4" />
    </svg>
  )
}

// Eye Off Icon
function EyeOffIcon() {
  return (
    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M9.88 9.88a3 3 0 1 0 4.24 4.24M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61M2 2l20 20" />
    </svg>
  )
}

// Eye Icon
function EyeIcon() {
  return (
    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  )
}

// Smartphone Icon
function SmartphoneIcon() {
  return (
    <svg className="w-4 h-4 text-[#e32929] flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="5" y="2" width="14" height="20" rx="2" ry="2" />
      <line x1="12" y1="18" x2="12.01" y2="18" />
    </svg>
  )
}

export default function LoginPage({ onLogin }) {
  const [showPassword, setShowPassword] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-white font-[Inter,system-ui,sans-serif]">

      {/* ── LEFT PANEL ── */}
      <div className="relative hidden md:flex md:w-[40%] flex-col bg-[#e32929] overflow-hidden">
        
        {/* Top white curve cutout */}
        <div className="absolute top-0 right-0 w-[140px] h-[140px] bg-white rounded-bl-[140px] z-20" />

        {/* Logo */}
        <div className="relative z-10 pt-10 pl-10">
          <LiciousLogo invert={true} heightClass="h-14" />
        </div>

        {/* Headline & Description */}
        <div className="relative z-10 mt-24 px-10">
          <h1 className="text-white text-[38px] font-extrabold leading-[1.15] tracking-tight">
            Real Good.<br />Admin Access.
          </h1>
          <p className="text-white/85 text-[14px] mt-6 leading-[1.6] font-normal max-w-[310px]">
            Welcome to the Licious Admin Portal.<br />
            Manage orders, customers, inventory<br />
            and more — all in one place.
          </p>
        </div>

        {/* Meat Hero Image */}
        <div className="relative z-10 flex-1 flex items-center justify-center px-6 -mt-8">
          <img
            src={meatHero}
            alt="Fresh premium meat"
            className="w-[90%] max-w-[390px] object-contain drop-shadow-[0_20px_40px_rgba(0,0,0,0.35)]"
          />
        </div>

        {/* Bottom bar with quality badges */}
        <div className="relative z-10 mt-auto px-12 pb-10 pt-6">
          <div className="flex items-center justify-between text-white text-[11px] gap-2">
            
            {/* Trusted Quality */}
            <div className="flex items-center gap-2.5">
              <ShieldIcon />
              <span className="font-semibold leading-tight tracking-wide">
                Trusted<br />Quality
              </span>
            </div>
            
            {/* Divider */}
            <div className="w-px h-8 bg-white/20" />
            
            {/* Freshly Made */}
            <div className="flex items-center gap-2.5">
              <SnowflakeIcon />
              <span className="font-semibold leading-tight tracking-wide">
                Freshly<br />Made
              </span>
            </div>
            
            {/* Divider */}
            <div className="w-px h-8 bg-white/20" />
            
            {/* Hygienically Packed */}
            <div className="flex items-center gap-2.5">
              <HeartIcon />
              <span className="font-semibold leading-tight tracking-wide">
                Hygienically<br />Packed
              </span>
            </div>

          </div>
        </div>

      </div>

      {/* ── RIGHT PANEL ── */}
      <div className="flex-1 bg-white flex flex-col items-center justify-center p-6 relative">

        {/* Form Card */}
        <div className="w-full max-w-[480px] border border-black rounded-lg p-11 pb-12 bg-white shadow-none mx-4 mt-6">
          
          {/* Logo inside Card */}
          <div className="flex justify-center mb-5">
            <LiciousLogo heightClass="h-[52px]" />
          </div>

          {/* Titles */}
          <h2 className="text-[32px] font-extrabold text-gray-900 text-center tracking-tight leading-none">Admin Login</h2>
          <p className="text-gray-500 text-xs text-center mt-1.5 mb-8">Access your admin dashboard</p>

          {/* Email Field */}
          <div className="mb-5">
            <label htmlFor="email" className="block text-[13px] font-medium text-gray-700 mb-2">
              Email Address
            </label>
            <div className="flex items-center border border-gray-300 rounded-md px-4 py-3.5 gap-3 focus-within:border-black transition-all">
              <EmailIcon />
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email address"
                className="flex-1 text-sm text-gray-800 placeholder-gray-400 outline-none bg-transparent"
              />
            </div>
          </div>

          {/* Password Field */}
          <div className="mb-2.5">
            <label htmlFor="password" className="block text-[13px] font-medium text-gray-700 mb-2">
              Password
            </label>
            <div className="flex items-center border border-gray-300 rounded-md px-4 py-3.5 gap-3 focus-within:border-black transition-all">
              <LockIcon />
              <input
                id="password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                className="flex-1 text-sm text-gray-800 placeholder-gray-400 outline-none bg-transparent"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="text-gray-400 hover:text-gray-600 transition-colors cursor-pointer"
                aria-label="Toggle password visibility"
              >
                {showPassword ? <EyeIcon /> : <EyeOffIcon />}
              </button>
            </div>
          </div>

          {/* Forgot Password */}
          <div className="flex justify-end mb-6">
            <button
              type="button"
              className="text-xs font-semibold text-[#e32929] hover:underline transition-all cursor-pointer"
            >
              Forgot password?
            </button>
          </div>

          {/* Login Button */}
          <button
            id="login-btn"
            type="button"
            onClick={onLogin}
            className="w-full bg-[#e32929] hover:bg-[#c41f1f] active:bg-[#a81a1a] text-white font-bold py-4 rounded-md transition-all duration-200 text-sm tracking-wide cursor-pointer"
          >
            Login
          </button>

          {/* OR Divider */}
          <div className="flex items-center gap-4 my-6">
            <div className="flex-1 h-px bg-gray-200" />
            <span className="text-xs text-gray-400 font-medium">or</span>
            <div className="flex-1 h-px bg-gray-200" />
          </div>

          {/* Login with OTP Button */}
          <button
            id="login-otp-btn"
            type="button"
            onClick={onLogin}
            className="w-full flex items-center justify-center gap-2.5 border border-[#e32929] text-[#e32929] hover:bg-red-50/30 active:bg-red-100/30 font-bold py-4 rounded-md transition-all duration-200 text-sm tracking-wide cursor-pointer"
          >
            <SmartphoneIcon />
            Login With OTP
          </button>

        </div>

        {/* Centered Footer */}
        <div className="mt-8 text-center z-10">
          <p className="text-xs text-gray-400">
            © 2026 <span className="text-[#e32929] font-medium">Licious</span>. All rights reserved
          </p>
        </div>

      </div>
    </div>
  )
}

